package com.ivy.drawableanimationdemo;

import android.app.Activity;
import android.graphics.drawable.AnimationDrawable;
import android.os.Bundle;
import android.view.Menu;
import android.view.View;
import android.widget.ImageView;

public class MainActivity extends Activity {

	protected ImageView ivWifi;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		
		ivWifi = (ImageView)findViewById(R.id.imageView1);
		
		this.findViewById(R.id.button1).setOnClickListener(new View.OnClickListener() {
			
			@Override
			public void onClick(View v) {
				ivWifi.setBackgroundResource(R.anim.anim_wifi);  
                AnimationDrawable anim = (AnimationDrawable) ivWifi.getDrawable();  
                
				if(anim.isRunning()){
					anim.stop();
				}else{
					anim.stop();
					anim.start();
				}
			}
		});

	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.main, menu);
		return true;
	}

}
